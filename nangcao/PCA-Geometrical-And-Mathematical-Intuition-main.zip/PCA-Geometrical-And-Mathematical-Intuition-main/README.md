# PCA-Geometrical-And-Mathematical-Intuition

## Check out the Best Affordable Data Science Course From Pwskills(6-7 Months)
Impact Batch:- Data-Science-Masters (Full Stack Data Science)

Data Science Masters Hindi: https://bit.ly/3CKX1od (Hindi)

Data Science Masters English: https://bit.ly/3iEjWuH (English)
